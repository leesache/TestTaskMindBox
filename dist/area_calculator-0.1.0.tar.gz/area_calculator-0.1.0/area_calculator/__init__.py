"""
Area Calculator package for calculating areas of different shapes.
"""
