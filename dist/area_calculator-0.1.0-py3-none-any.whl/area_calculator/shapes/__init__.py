"""
Shapes module containing different geometric shapes.
"""
